const config = {
  backendUrl: 'http://localhost:3000', // Change this for production
  // Add other configuration options as needed
};

export default config;
