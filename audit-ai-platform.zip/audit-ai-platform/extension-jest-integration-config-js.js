module.exports = {
  testEnvironment: 'jsdom',
  testMatch: ['**/tests/integration/**/*.test.js'],
  setupFilesAfterEnv: ['./tests/setup.js']
};
