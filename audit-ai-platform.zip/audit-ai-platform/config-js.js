module.exports = {
  notionIntegrationEnabled: process.env.ENABLE_NOTION_INTEGRATION === 'true' || false,
  // Add other feature flags here
};
